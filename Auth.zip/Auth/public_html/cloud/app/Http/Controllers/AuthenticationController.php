<?php

namespace App\Http\Controllers;

use App\Helpers\Post;
use Illuminate\Routing\ResponseFactory;
use Illuminate\Http\Request;


use Illuminate\Support\Facades\Artisan;
use PHPUnit\Framework\ExpectationFailedException;
use Symfony\Component\HttpKernel\Exception\HttpException;
use App\Helpers\JWT;
use App\JWT\ReallySimpleJWT\Token;

class AuthenticationController extends Controller
{

    public function login(Request $request)
    {


        $email = $request->json('email');
        $pass = $request->json('pass');

        $loginUrl = "dbapache/cloud/public/api/login";

        $result = Post::send($loginUrl, ['email' => $email, 'pass' => $pass]);

        if ($result->status == "done") {
            return response()->json(['status' => 'done', 'token' => $result->token, 'id' => $result->id]);
        } else {
            return response()->json(['status' => 'error'], 403);
        }


    }

	public function tokenValidate(Request $request)
    {


 		$token = $request->post('token') != null ? JWT::validate($request->post('token')) : null;
if($token != null){
 return response()->json(['status' => 'done', 'token'=>$token], 200);
}else {
 return response()->json(['status' => 'error'], 403);
}
           


    }




}
